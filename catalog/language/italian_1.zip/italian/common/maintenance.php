<?php
// Heading
$_['heading_title']    = 'In Manutenzione';

// Text
$_['text_maintenance'] = 'Manutenzione';
$_['text_message']     = '<h1 style="text-align:center;">Sito momentaneamente in manutenzione. <br/>Torneremo on-line il prima possibile.</h1>';
?>