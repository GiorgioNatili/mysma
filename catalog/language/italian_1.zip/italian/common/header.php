<?php
// Text
$_['text_home']           = 'Home';
$_['text_wishlist']       = 'Preferiti (%s)';
$_['text_shopping_cart']  = 'Carrello';
$_['text_search']         = 'Cerca';
$_['text_welcome']        = 'Benvenuto visitatore, effettua il <a href="%s">login</a> o <a href="%s">crea un nuovo account</a>.';
$_['text_logged']         = 'Sei loggato come <a href="%s">%s</a> <b>(</b> <a href="%s">Logout</a> <b>)</b>';
$_['text_account']        = 'Account';
$_['text_checkout']       = 'Cassa';
$_['text_currency'] = 'Valuta';
$_['text_cart'] = 'Carrello';
$_['text_items'] = 'Carrello';
$_['text_language'] = 'Lingua';
$_['text_additional'] = 'Note';
?>