<?php
// Heading 
$_['heading_title'] = 'Carrello';

// Text
$_['text_items']    = '%s voce(i) - %s';
$_['text_empty']    = 'Il tuo carrello &egrave; vuoto!';
$_['text_cart']     = 'Guarda il carrello';
$_['text_checkout'] = 'Cassa';
?>