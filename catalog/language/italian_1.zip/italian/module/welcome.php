<?php
$_['heading_title'] = 'Benvenuto su %s';
?>