<?php
// Heading 
$_['heading_title'] = 'Bestsellers';

// Text
$_['text_reviews']  = 'Basato su %s giudizi.'; 
?>