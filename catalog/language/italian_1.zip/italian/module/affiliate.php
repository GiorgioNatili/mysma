<?php
// Heading 
$_['heading_title']    = 'Affiliate';

// Text
$_['text_register']    = 'Registrati';
$_['text_login']       = 'Login';
$_['text_logout']      = 'Logout';
$_['text_forgotten']   = 'Password Persa';
$_['text_account']     = 'Il mio Account';
$_['text_edit']        = 'Modifica Account';
$_['text_password']    = 'Password';
$_['text_payment']     = 'Opzioni PAgamento';
$_['text_tracking']    = 'Monitoraggio Affiliato';
$_['text_transaction'] = 'Transazioni';
?>
