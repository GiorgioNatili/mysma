<?php
// Heading 
$_['heading_title'] = 'Specials';

// Text
$_['text_reviews']  = 'Basato su %s giudizi.'; 
?>