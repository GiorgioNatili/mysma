<?php
// Heading 
$_['heading_title']    = 'Account';

// Text
$_['text_register']    = 'Registrati';
$_['text_login']       = 'Login';
$_['text_logout']      = 'Logout';
$_['text_forgotten']   = 'Password Persa';
$_['text_account']     = 'Il mio Account';
$_['text_edit']        = 'Modifica Account';
$_['text_password']    = 'Password';
$_['text_wishlist']    = 'Lista Desideri';
$_['text_order']       = 'Storico Ordini';
$_['text_download']    = 'Downloads';
$_['text_return']      = 'Restituzioni';
$_['text_transaction'] = 'Transazioni';
$_['text_newsletter']  = 'Newsletter';
?>
