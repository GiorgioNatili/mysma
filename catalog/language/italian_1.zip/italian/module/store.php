<?php
// Heading 
$_['heading_title'] = 'Scegli un negozio';

// Text
$_['text_default']  = 'Default';
$_['text_store']    = 'Seleziona un negozio che desideri visitare.';
?>