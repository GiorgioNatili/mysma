<?php
// Heading 
$_['heading_title']   = 'Hai Smarrito La Password?';

// Text
$_['text_account']    = 'Account';
$_['text_forgotten']  = 'Password Dimenticata';
$_['text_your_email'] = 'La Tua E-Mail';
$_['text_email']      = 'Inserisci l\'indirizzo mail associato all\'account. Clicca su SUBMIT per ricevere la nuova password.';
$_['text_success']    = 'Una nuova password &egave; stata inviata al tuo indirizzo mail.';

// Entry
$_['entry_email']     = 'Indirizzo e-mail:';

// Error
$_['error_email']     = 'Attenzione: L\'indirizzo e-mail non &egrave, stato trovato, riprova!';
?>