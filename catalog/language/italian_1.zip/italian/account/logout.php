<?php
// Heading 
$_['heading_title'] = 'Account Logout';

// Text
$_['text_message']  = '<p>Sei stato disconnesso dal tuo account</p><p>Il carrello &egrave; stato salvato, gli elementi al suo interno verranno ripristinati ogni volte che accederai al tuo account</p>';
$_['text_account']  = 'Account';
$_['text_logout']   = 'Logout';
?>