<?php
// Heading
$_['heading_title'] = 'Il Tuo Account &Egrave; Stato Creato!';

// Text
$_['text_message']  = '<p>Congratulazioni! Il tuo nuovo account &egrave; stato creato con successo! </p> Ora &egrave; possibile approfittare di privilegi riservati ai membri per migliorare la vostra esperienza di shopping on-line con noi. </ P> Se avete domande sul funzionamento di questo e-commerce invaite una mail al resposabile del negozio.';
$_['text_approval'] = '<p>Grazie per esserti registrato %s!</p><p>Riceverai una mail appena sar&agrave; attivato il tuo account.</p><p>Se hai una qualsiasi domanda, <a href="%s">contattaci</a>.</p>';
$_['text_account']  = 'Account';
$_['text_success']  = 'Successo';
?>