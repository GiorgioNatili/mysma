<?php
// Heading
$_['heading_title'] = 'La pagina richiesta non &egrave; stata trovata!';

// Text
$_['text_error']    = 'La pagina richiesta non &egrave; stata trovata.';
?>