<?php
// Text
$_['text_title']  = 'Spedizion basata sul peso';
$_['text_weight'] = 'Peso:'; 
?>