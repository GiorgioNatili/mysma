<?php
// Heading 
$_['heading_title'] = 'Account Logout';

// Text
$_['text_message']  = '<p>Hai effettuato i logout dal tuo Account Affiliato.</p>';
$_['text_account']  = 'Account';
$_['text_logout']   = 'Logout';
?>