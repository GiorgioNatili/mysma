<?php
// Heading 
$_['heading_title']  = 'CAmbio Password';

// Text
$_['text_account']   = 'Account';
$_['text_password']  = 'Password';
$_['text_success']   = 'La tua password &egrave; stata aggiornata correttamente.';

// Entry
$_['entry_password'] = 'Password:';
$_['entry_confirm']  = 'conferma Password:';

// Error
$_['error_password'] = 'La password deve contenere tra i 2 e i 20 caratteri!';
$_['error_confirm']  = 'Le password non coincidono!';
?>