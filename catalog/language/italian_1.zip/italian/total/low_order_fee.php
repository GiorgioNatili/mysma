<?php
$_['text_low_order_fee'] = 'Ordine a basso tasso';
?>