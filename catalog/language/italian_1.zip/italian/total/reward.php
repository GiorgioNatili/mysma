<?php


// No Permission
defined('_JEXEC') or die('Accesso riservato');

// Heading 
$_['heading_title'] = 'Usa punti fedeltà (Disponibili %s)';

// Text
$_['text_reward']   = 'Punti Fedeltà(%s)';
$_['text_order_id'] = 'Ordine ID: #%s';
$_['text_success']  = 'Successo: Lo sconto con i punti fedeltà è stato inserito!';

// Entry
$_['entry_reward']  = 'Punti da usare (Max %s):';

// Error
$_['error_empty']   = 'Errore: Inserisci quanti punti vuoi usare';
$_['error_points']  = 'Errore: Non hai %s punti fedeltà!';
$_['error_maximum'] = 'Errore: Il massimo dei punti applicabili è %s!';
?>