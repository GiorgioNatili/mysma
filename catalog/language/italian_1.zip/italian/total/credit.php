<?php
$_['text_credit']   = 'Credito';
$_['text_order_id'] = 'ID Ordine: #%s';
?>