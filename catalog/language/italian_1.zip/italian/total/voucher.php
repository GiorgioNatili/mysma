<?php


// No Permission
defined('_JEXEC') or die('Accesso riservato');

// Heading 
$_['heading_title'] = 'Inserisci codice Premio';

// Text
$_['text_voucher']  = 'Voucher(%s)';
$_['text_success']  = 'Successo: il tuo codice premio è stato aggiunto!';

// Entry
$_['entry_voucher'] = 'Inserisci il codice premio qua:';

// Error
$_['error_voucher'] = 'Errore: Il codice premio è scaduto o non è valido!';
?>