<?php


// No Permission
defined('_JEXEC') or die('Accesso riservato');

// Heading 
$_['heading_title'] = 'Inserisci un Coupon';

// Text
$_['text_coupon']   = 'Coupon(%s)';
$_['text_success']  = 'Successo: Il tuo coupon è stato applicato!';

// Entry
$_['entry_coupon']  = 'Inserisci il tuo coupon qua:';

// Error
$_['error_coupon']  = 'Errore: Il coupon inserito non è valido oppure è scaduto!';
?>