<?php
// Text
$_['text_title'] = 'Contrassegno';
?>