<?php
// Text
$_['text_title'] = 'PayPal Express (Include Carte di Credito e di Debito)';
?>