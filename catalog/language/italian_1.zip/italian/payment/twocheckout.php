<?php
// Text
$_['text_title'] = 'Carta di Credito o di Debito (2Checkout)';
?>