<?php
// Entry
$_['entry_postcode'] = 'Post Code:';
$_['entry_country']  = 'Country:';
$_['entry_zone']     = 'Region / State:';
?>