<?php
// Text
$_['text_title']    = 'PayPal';
$_['text_reason'] 	= 'REASON';
$_['text_testmode']	= 'Attenzinoe: Il Gateway di pagamento &egrave; in \'Sandbox Mode\'. No ti sar&agrave; addebbitato l\'importo.';
$_['text_total']	= 'Trasporto, sconti e Tassse';
?>