<?php
// Text
$_['text_title'] = 'Ritiro in sede';
?>