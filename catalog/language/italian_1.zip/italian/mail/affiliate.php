<?php
// Text
$_['text_subject']  = '%s - Programma Affiliato';
$_['text_welcome']  = 'Grazie per aver aderito al programma affiliati di %s!';
$_['text_approval'] = 'Il tuo account deve essere approvato prima di poter effettuare il login. Una volta approvato &egrave; possibile accedere utilizzando il tuo indirizzo email e la password seguente URL:';
$_['text_services'] = 'Una volta effettuato l\'accesso, si sar&agrave; in grado di generare codici di monitoraggio, monitorare i pagamenti delle commissioni e modificare le informazioni del tuo account.';
$_['text_thanks']   = 'Grazie,';
?>