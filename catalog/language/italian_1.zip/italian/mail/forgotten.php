<?php
// Text
$_['text_subject']  = '%s - Nuova Password';
$_['text_greeting'] = 'Una nuova password &egrave; stata richiesta da %s.';
$_['text_password'] = 'La tua nuova password &egrave;:';
?>