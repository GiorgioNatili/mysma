<?php
// Text
$_['text_subject']  = 'Ti &egrave; stato inviato un buono regalo da %s';
$_['text_greeting'] = 'Congratulazioni, Hai ricevuto un buono regalo del valore di %s';
$_['text_from']     = 'Questo buono regalo ti &egrave; stato inviato da %s';
$_['text_message']  = 'Con un messaggio che dice:';
$_['text_redeem']   = 'Per riscattare il Buono Regalo, annotare il codice di redenzione che &egrave;<b>%s</b> quindi fate clic sul link qui sotto e acquistare il prodotto che si desidera utilizzando questo buono regalo. &Egrave; possibile immettere il codice del buono omaggio sulla pagina del carrello prima di scegliere il checkout.';
$_['text_footer']   = 'Si prega di rispondere a questa e-mail se avete domande o dubbi. Grazie';
?>