<?php
// Heading
$_['heading_title'] = 'Il tuo account Affiliato &egrave; stato creato!';

// Text 
$_['text_approval'] = '<p>Grazie per la registrazione di un Profilo affiliato con %s!</p><p>Riceverai una notifica via e-mail una volta che il tuo Profilo � stato attivato dal proprietario del negozio.</p><p>Se avete domande sul funzionamento di questo sistema di affiliazione, per favore <a href="%s">contatta il proprietaro del negozio</a>.</p>';
$_['text_account']  = 'Profilo';
$_['text_success']  = 'Successo';
?>