<?php
// Heading 
$_['heading_title'] = 'Logout dal Profilo';

// Text
$_['text_message']  = '<p>Hai effettuato i logout dal tuo Profilo Affiliato.</p>';
$_['text_account']  = 'Profilo';
$_['text_logout']   = 'Logout';
?>