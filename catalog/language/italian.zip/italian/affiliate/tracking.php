<?php
// Heading 
$_['heading_title']    = 'Monitoraggio Affiliato';

// Text
$_['text_account']     = 'Profilo';
$_['text_description'] = 'Per assicurarsi che tu vienga pagato per i referral ci vengono inviati, abbiamo bisogno di rintracciare il rinvio mettendo un codice di monitoraggio nelle'URL\'s collegate a noi. &Egrave; possibile utilizzare gli strumenti di seguito per generare link al sito web %s.';
$_['text_code']        = '<b>Codice di tracciamento:</b>';
$_['text_generator']   = '<b>Generatore di link per il monitoraggio</b><br />Digitare il nome di un prodotto che si desidera collegare a:';
$_['text_link']        = '<b>Tracking Link:</b>';
?>