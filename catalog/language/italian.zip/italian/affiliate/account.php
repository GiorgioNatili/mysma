<?php
// Heading 
$_['heading_title']        = 'Affiliato';

// Text
$_['text_account']         = 'Profilo';
$_['text_my_account']      = 'Profilo Affiliato';
$_['text_my_tracking']     = 'Monitoraggio delle mie informazioni';
$_['text_my_transactions'] = 'Le mie transazioni';
$_['text_edit']            = 'Modifica le tue informazioni';
$_['text_password']        = 'Cambia la tua password';
$_['text_payment']         = 'Cambia le preferenze di pagamento';
$_['text_tracking']        = 'Codice di monitoraggio personalizzato';
$_['text_transaction']     = 'Lo storico delle tue transazioni';
?>