<?php
// Text
$_['text_title']       = 'Ritiro in sede';
$_['text_description'] = 'Ritiro in sede';
?>