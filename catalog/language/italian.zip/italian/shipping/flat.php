<?php
// Text
$_['text_title']       = 'Prezzo Fisso';
$_['text_description'] = 'Spedizione a costo fisso';
?>