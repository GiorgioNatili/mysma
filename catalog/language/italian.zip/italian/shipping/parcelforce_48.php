<?php
// Text
$_['text_title']       = 'PaccoCelere 48';
$_['text_description'] = 'PaccoCelere 48';
$_['text_weight']      = 'Peso:'; 
$_['text_insurance']   = 'Assicurato fino a:';   
$_['text_time']        = 'Tempo stimato: 48 Ore'; 
?>