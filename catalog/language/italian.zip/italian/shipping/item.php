<?php
// Text
$_['text_title']       = 'Per Articolo';
$_['text_description'] = 'Spedizione calcolata ad articolo';
?>