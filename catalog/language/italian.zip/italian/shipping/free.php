<?php
// Text
$_['text_title']       = 'Gratis';
$_['text_description'] = 'Spedizione Gratuita';
?>