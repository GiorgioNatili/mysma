<?php
$_['text_total'] = 'Totale';
?>