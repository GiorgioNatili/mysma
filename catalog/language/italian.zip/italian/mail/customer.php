<?php
// Text
$_['text_subject']  = '%s - Grazie per esserti registrato';
$_['text_welcome']  = 'Benvenuto e grazie per esserti registrato su %s!';
$_['text_login']    = 'Il tuo account &egrave; stato creato ora &egrave; possibile accedere utilizzando il tuo indirizzo email e la password visitando il nostro sito o al seguente URL:';
$_['text_approval'] = 'Il tuo account deve essere approvato prima di poter effettuare il login. Una volta approvato &egrave; possibile accedere utilizzando il tuo indirizzo email e la password visitando il nostro sito o al seguente indirizzo:';
$_['text_services'] = 'Una volta effettuato l\'accesso, potrai accedere ad altri servizi tra cui la revisione ordini passati, la stampa delle fatture e modificare le informazioni sull\'account.';
$_['text_thanks']   = 'Grazie,';
?>