<?php
// Heading 
$_['heading_title'] = 'In primo Piano';

// Text
$_['text_reviews']  = 'Basato su %s giudizi.'; 
?>