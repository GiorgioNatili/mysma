<?php
// Heading 
$_['heading_title'] = 'Ultimi arrivi';

// Text
$_['text_reviews']  = 'Basato su %s giudizi.'; 
?>