<?php
// Heading 
$_['heading_title'] = 'Informazioni';

// Text
$_['text_contact']  = 'Contattaci';
$_['text_sitemap']  = 'Site Map';
?>