<?php

$_['brand_products'] = '%s %s';

// Main Menu
$_['menu_inside']      = 'Inside %s';
$_['menu_brands']      = '%s Brands';
$_['menu_information'] = 'Information';