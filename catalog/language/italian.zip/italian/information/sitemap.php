<?php
// Heading
$_['heading_title']    = 'Site Map';
 
// Text
$_['text_special']     = 'Offerte Speciali';
$_['text_account']     = 'Profilo';
$_['text_edit']        = 'Informazioni Profilo';
$_['text_password']    = 'Password';
$_['text_address']     = 'Rubrica Indirizzi';
$_['text_history']     = 'Storico Ordini';
$_['text_download']    = 'Downloads';
$_['text_cart']        = 'Carrello';
$_['text_checkout']    = 'Cassa';
$_['text_search']      = 'Cerca';
$_['text_information'] = 'Infrmazioni';
$_['text_contact']     = 'Contataci';
?>
