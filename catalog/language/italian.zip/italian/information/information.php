<?php
// Text
$_['text_error'] = 'Pagina non trovata!';
?>