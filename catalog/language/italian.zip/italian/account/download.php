<?php
// Heading 
$_['heading_title']   = 'Downloads';

// Text
$_['text_account']    = 'Profilo';
$_['text_downloads']  = 'Downloads';
$_['text_order']      = 'Order ID:';
$_['text_date_added'] = 'Data di inserimento:';
$_['text_name']       = 'Nome:';
$_['text_remaining']  = 'Rimanente:';
$_['text_size']       = 'Dimensione:';
$_['text_empty']      = 'Non ci sono ordini scaricabili!';
?>