<?php
// Heading 
$_['heading_title'] = 'Logout dal Profilo';

// Text
$_['text_message']  = '<p>Sei stato disconnesso dal tuo Profilo</p><p>Il carrello &egrave; stato salvato, gli elementi al suo interno verranno ripristinati ogni volte che accederai al tuo Profilo</p>';
$_['text_account']  = 'Profilo';
$_['text_logout']   = 'Logout';
?>