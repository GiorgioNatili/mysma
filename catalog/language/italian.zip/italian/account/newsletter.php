<?php
// Heading 
$_['heading_title']    = 'Newsletter';

// Text
$_['text_account']     = 'Profilo';
$_['text_newsletter']  = 'Newsletter';
$_['text_success']     = 'La tua iscrizione alla newsletter &egrave; avvenuta con successo!';

// Entry
$_['entry_newsletter'] = 'Sottoscrivi:';
?>
