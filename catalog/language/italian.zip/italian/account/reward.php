<?php
// Heading 
$_['heading_title']      = 'I tuoi punti';

// Column
$_['column_date_added']  = 'Data Inserimento';
$_['column_description'] = 'Descrizione';
$_['column_points']      = 'Punti';

// Text
$_['text_account']       = 'Profilo';
$_['text_reward']        = 'Punti premio';
$_['text_total']         = 'Il totale dei tuoi punti &egrave;:';
$_['text_empty']         = 'Non hai acumulato punti!';
?>