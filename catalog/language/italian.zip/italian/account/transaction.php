<?php
// Heading 
$_['heading_title']      = 'Le tue transazioni';

// Column
$_['column_date_added']  = 'Data inserimento';
$_['column_description'] = 'Descrizione';
$_['column_amount']      = 'Importo (%s)';

// Text
$_['text_account']       = 'Profilo';
$_['text_transaction']   = 'Le tue transazioni';
$_['text_total']         = 'Il saldo corrente &egrave;:';
$_['text_empty']         = 'Non hai transazioni!';
?>