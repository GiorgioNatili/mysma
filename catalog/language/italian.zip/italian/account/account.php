<?php
// Heading 
$_['heading_title']      = 'Profilo';

// Text
$_['text_account']       = 'Profilo';
$_['text_my_account']    = 'Il mio Profilo';
$_['text_my_orders']     = 'I miei ordini';
$_['text_my_newsletter'] = 'Newsletter';
$_['text_edit']          = 'Modifica le informazioni del tuo Profilo';
$_['text_password']      = 'Cambia la tua password';
$_['text_address']       = 'Modifica i tuoi indirizzi';
$_['text_wishlist']      = 'Modifica i tuoi Preferiti';
$_['text_order']         = 'Guarda lo storico ordini';
$_['text_download']      = 'Downloads';
$_['text_reward']        = 'I tuoi punti'; 
$_['text_return']        = 'Visualizza le tue richieste di sostituzione'; 
$_['text_transaction']   = 'Le tue transazioni'; 
$_['text_newsletter']    = 'Sottoscivi / Cancellati dalla newsletter';
?>