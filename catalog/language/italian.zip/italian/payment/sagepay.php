<?php
// Text
$_['text_title']       = 'Carta di Credito / Carta di Debito (SagePay)';
$_['text_description'] = 'Articoli su %s Ordine No: %s';
?>