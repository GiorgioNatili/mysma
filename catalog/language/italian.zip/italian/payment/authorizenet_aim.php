<?php
// Text
$_['text_title']           = 'Carta di Credito / Carta di Debito (Authorize.Net)';
$_['text_credit_card']     = 'Dettagli Carta di Credito';
$_['text_wait']            = 'Attendere!';

// Entry
$_['entry_cc_owner']       = 'Titolare Carta:';
$_['entry_cc_number']      = 'Numero Carta:';
$_['entry_cc_expire_date'] = 'Data scadenza Carta:';
$_['entry_cc_cvv2']        = 'Codice di verifica (CVV2):';
?>