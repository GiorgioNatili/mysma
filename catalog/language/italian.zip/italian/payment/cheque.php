<?php
// Text
$_['text_title']       = 'Informazioi Assegno';
$_['text_instruction'] = 'Per Assegno';
$_['text_payable']     = 'Intestato a: ';
$_['text_address']     = 'Invia a: ';
$_['text_payment']     = 'Il tuo ordine non sar&agrave; avaso fino a ricevimento del pagamento.';
?>