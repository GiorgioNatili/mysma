<?php
// Text
$_['text_title']       = 'Bonifico Bancario';
$_['text_instruction'] = 'Informazioni per il Bonifico Bancario';
$_['text_description'] = 'Bonifica l\'importo sul seguente conto corrente bancario.';
$_['text_payment']     = 'Il tuo ordine non sar&agrave; avaso fino a ricevimento del pagamento.';
?>