<?php
// Text
$_['text_information']  = 'Informazioni';
$_['text_service']      = 'Servizio Clienti';
$_['text_extra']        = 'Extra';
$_['text_contact']      = 'Contattaci';
$_['text_return']       = 'Resi';
$_['text_sitemap']      = 'Sitemap';
$_['text_manufacturer'] = 'Produttori';
$_['text_voucher']      = 'Buoni Regalo';
$_['text_affiliate']    = 'Affiliati';
$_['text_special']      = 'Speciali';
$_['text_account']      = 'Profilo';
$_['text_order']        = 'Storico Ordini';
$_['text_wishlist']     = 'Preferiti';
$_['text_newsletter']   = 'Newsletter';
$_['text_powered']      = '<center>Powered by <a href="http://www.ilogic.it">iLogic</a></center><br /> %s &copy; %s';
?>